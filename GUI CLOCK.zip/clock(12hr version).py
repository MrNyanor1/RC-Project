from datetime import datetime
from tkinter import *
import tkinter



# define some colors
cor1 = "#ffffff" # white
cor2 = "#000000" # black

root = Tk()
root.title("Clock")
root.geometry('260x70')
root.resizable(width=FALSE, height=FALSE)
root.configure(background=cor1)
FPS = 50

def clock():
    time = datetime.now()
    hour = time.strftime("%-I:%M:%S %p")
    weekday = time.strftime("%A")
    day = time.day
    month = time.strftime("%B")
    year=time.strftime("%Y")
    l1.config(text=hour)
    l1.after(200, clock)

    l2.config(text=weekday + ", " + str(month) +" " + str(day) + ", " + (year))


l1 = Label(root, font=('Waltograph 20'), bg=cor1, fg=cor2)
l1.grid(row=0, column=0, sticky=NE)

l2 = Label(root, font=('Waltograph 15'), bg=cor1, fg=cor2)
l2.grid(row=1, column=0, sticky=NE)

clock()
root.mainloop()
