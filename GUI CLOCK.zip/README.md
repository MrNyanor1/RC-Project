# Python Clock

A simple digital clock built with Python that displays the current time and updates every second. It has two versions (12-hour clock and 24-hour clock). It is the GUI Python Clock.

## Features

- Real-time clock display
- Updates every second
- Easy to customize
- Beginner-friendly project

## Requirements

- Python 3.x

## Installation

1. Clone or download this project.
2. Open a terminal in the project folder.

## Usage

Run the scripts:

```bash
clock(12hr version).py

and

clock(24hr version).py